from types import SimpleNamespace, ModuleType
import importlib.util
import re
import sys
import textwrap

google_mod = ModuleType("google")
genai_mod = ModuleType("google.genai")
types_mod = ModuleType("google.genai.types")
google_mod.genai = genai_mod
genai_mod.types = types_mod
sys.modules["google"] = google_mod
sys.modules["google.genai"] = genai_mod
sys.modules["google.genai.types"] = types_mod
sys.path.insert(0, ".")

spec = importlib.util.spec_from_file_location("daily_tsmc_report", "./daily_tsmc_report.py")
mod = importlib.util.module_from_spec(spec)
sys.modules["daily_tsmc_report"] = mod
spec.loader.exec_module(mod)

raw = textwrap.dedent("""
正文第一段。
正文第二段。
<<<LINE_SUMMARY>>>
- 最近收盤價：1,860.00
- 最近漲跌價差：50.00
- 最近成交股數：19,895,445
- 明日偏多
<<<END_LINE_SUMMARY>>>
""").strip()

chunks = [
    SimpleNamespace(web=SimpleNamespace(uri="https://example.com/a", title="a")),
    SimpleNamespace(web=SimpleNamespace(uri="https://example.com/b", title="b")),
]
supports = [
    SimpleNamespace(segment=SimpleNamespace(start_index=0, end_index=5), grounding_chunk_indices=[0]),
    SimpleNamespace(segment=SimpleNamespace(start_index=20, end_index=40), grounding_chunk_indices=[1]),
    SimpleNamespace(segment=SimpleNamespace(start_index=70, end_index=85), grounding_chunk_indices=[0, 1]),
    SimpleNamespace(
        segment=SimpleNamespace(
            start_index=100,
            end_index=raw.index("<<<END_LINE_SUMMARY>>>") + len("<<<END_LINE_SUMMARY>>>")
        ),
        grounding_chunk_indices=[1],
    ),
]
response = SimpleNamespace(
    text=raw,
    candidates=[SimpleNamespace(grounding_metadata=SimpleNamespace(
        grounding_supports=supports,
        grounding_chunks=chunks,
    ))],
)

excluded_ranges = mod.find_line_summary_ranges(raw)
cited_text = mod.add_inline_citations(response, excluded_ranges=excluded_ranges)
analysis_text, summary_text = mod.extract_line_summary(cited_text)

assert "<<<LINE_SUMMARY>>>" not in analysis_text
assert "<<<END_LINE_SUMMARY>>>" not in analysis_text
assert not re.search(r"\[\d+\]", summary_text)
assert "最近收盤價：1,860.00" in summary_text
print("PASS: LINE 摘要區塊已與 citation 插入邏輯正確分離。")
